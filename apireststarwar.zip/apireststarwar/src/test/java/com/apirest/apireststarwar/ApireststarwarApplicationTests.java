package com.apirest.apireststarwar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApireststarwarApplicationTests {

	@Test
	void contextLoads() {
	}

}
